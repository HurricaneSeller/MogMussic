package com.example.moan.mogmussic.util;

import android.util.Log;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class HTTPUtil {
    public static final String TAG = "moanbigking";
    private static final String BASE_URL = "https://api.hibai.cn/api/index/index";
    private static final String TRANSCODE_LRC = "020222";
    private static final String TRANSCODE_PIC = "020223";
    private static final String TRANSCODE_MUSIC_URL = "020224";
    private static final String TRANSCODE_SEARCH_MUSIC = "020225";
    private static final String songID = null;
    private static final String transCode = null;
    private static final String body = null;
    private static final String code = null;
    private static final String MODEL = "{\n" +
            "    \"TransCode\": \"" + transCode + "\",\n" +
            "    \"OpenId\": \"123456789\",\n" +
            "    \"Body\": {\n" +
            "        \"" + body + "\": \"" + code + "\"\n" +
            "    }\n" +
            "}\n";

    public static void getSongInfo(String songName) {
        HttpURLConnection connection;
        
        InputStream in = null;
        try {
            URL url = new URL(BASE_URL);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Charset", "UTF-8");
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setDoOutput(true);
            DataOutputStream out = new DataOutputStream(connection.getOutputStream());
            out.writeBytes(MODEL);
            out.flush();
            out.close();
            if (connection.getResponseCode() == 200) {
                in = connection.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);
                BufferedReader bufferedReader = new BufferedReader(reader);
                StringBuilder builder = new StringBuilder();
                String inputLine;
                while ((inputLine = bufferedReader.readLine()) != null) {
                    builder.append(inputLine);
                }
                Log.d(TAG, "getSongInfo: " + builder);
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
